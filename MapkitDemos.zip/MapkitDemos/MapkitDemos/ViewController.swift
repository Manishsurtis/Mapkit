//
//  ViewController.swift
//  MapkitDemos
//
//  Created by Manish Surti on 18/07/2017.
//  Copyright © 2017 ASquare.com. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class ViewController: UIViewController,CLLocationManagerDelegate{

    @IBOutlet weak var mapViewShow: MKMapView!
    let locationManager : CLLocationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
      
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[0]
        let locationss = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let span = MKCoordinateSpanMake(0.0075, 0.0075)
        let region = MKCoordinateRegionMake(locationss, span)
        
        mapViewShow.setRegion(region, animated: true)
        let annotation = MKPointAnnotation()
        annotation.title = "MyHome"
        annotation.subtitle = "India"
        annotation.coordinate = locationss
        mapViewShow.addAnnotation(annotation)
    }

}

